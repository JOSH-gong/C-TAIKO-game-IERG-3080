﻿using System.Configuration;
using System.Data;
using System.Windows;
using TaikoLite.Services;
using TaikoLite.ViewModels;

namespace TaikoLite
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var navigationService = new NavigationService();
            var mainViewModel = new MainViewModel(navigationService);

            navigationService.Navigate(new TitleViewModel(navigationService));

            var window = new MainWindow
            {
                DataContext = mainViewModel
            };

            window.Show();
        }
    }
}
