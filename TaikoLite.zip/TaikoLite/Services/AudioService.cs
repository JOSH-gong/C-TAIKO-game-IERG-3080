﻿using System;
using System.IO;
using System.Windows.Media;

namespace TaikoLite.Services
{
    public sealed class AudioService
    {
        private const int SfxPoolSize = 8;
        private const double BgmVolume = 0.4;
        private const double SfxVolume = 1.0;

        private readonly MediaPlayer _player = new();
        private readonly MediaPlayer[] _sfxPlayers = new MediaPlayer[SfxPoolSize];
        private int _nextSfxIndex;
        private double _requestedStartSec;

        public AudioService()
        {
            _player.MediaOpened += (_, __) =>
            {
                _player.Volume = BgmVolume;
                _player.Position = TimeSpan.FromSeconds(Math.Max(0, _requestedStartSec));
                _player.Play();
            };

            for (var i = 0; i < _sfxPlayers.Length; i++)
            {
                _sfxPlayers[i] = new MediaPlayer();
            }
        }

        public void PlayBgm(string relativePath, double startSec = 0)
        {
            StopBgm();

            if (string.IsNullOrWhiteSpace(relativePath))
                return;

            var absolutePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath);
            if (!File.Exists(absolutePath))
                return;

            _requestedStartSec = startSec;
            _player.Open(new Uri(absolutePath, UriKind.Absolute));
        }

        public void StopBgm()
        {
            try
            {
                _player.Stop();
                _player.Close();
            }
            catch
            {
            }
        }

        public void PlayHitRed() => PlaySfx("Assets/Audio/hit_red.mp3");

        public void PlayHitBlue() => PlaySfx("Assets/Audio/hit_blue.mp3");

        private void PlaySfx(string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath))
            {
                return;
            }

            var absolutePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath);
            if (!File.Exists(absolutePath))
            {
                return;
            }

            var player = _sfxPlayers[_nextSfxIndex];
            _nextSfxIndex = (_nextSfxIndex + 1) % _sfxPlayers.Length;

            try
            {
                player.Stop();
                player.Open(new Uri(absolutePath, UriKind.Absolute));
                player.Volume = SfxVolume;
                player.Position = TimeSpan.Zero;
                player.Play();
            }
            catch
            {
                // Ignore playback exceptions to avoid crashing the game during rapid hits.
            }
        }
    }
}
