using System;

namespace TaikoLite.Services
{
    /// <summary>
    /// Simple navigation service that tracks the currently active view model.
    /// </summary>
    public sealed class NavigationService : INavigationService
    {
        private object? _currentViewModel;

        public object? CurrentViewModel
        {
            get => _currentViewModel;
            private set
            {
                if (_currentViewModel == value)
                {
                    return;
                }

                _currentViewModel = value;
                CurrentViewModelChanged?.Invoke(this, EventArgs.Empty);
            }
        }

        public event EventHandler? CurrentViewModelChanged;

        public void Navigate(object viewModel)
        {
            if (viewModel == null)
            {
                throw new ArgumentNullException(nameof(viewModel));
            }

            CurrentViewModel = viewModel;
        }
    }
}
