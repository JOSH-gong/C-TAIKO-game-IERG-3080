using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows.Media;
using TaikoLite.Models;

namespace TaikoLite.Services
{
    public static class ChartLoader
    {
        public static List<Note> Load(string? chartPath)
        {
            var notes = new List<Note>();
            if (string.IsNullOrWhiteSpace(chartPath))
            {
                return notes;
            }

            var absolutePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, chartPath);
            if (!File.Exists(absolutePath))
            {
                return notes;
            }

            foreach (var rawLine in File.ReadAllLines(absolutePath))
            {
                var line = rawLine.Trim();
                if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#", StringComparison.Ordinal))
                {
                    continue;
                }

                var parts = line.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                if (parts.Length != 2)
                {
                    continue;
                }

                if (!double.TryParse(parts[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var timeSec))
                {
                    continue;
                }

                var noteType = parts[1].Trim().ToUpperInvariant();
                var brush = noteType switch
                {
                    "R" => Brushes.Red,
                    "B" => Brushes.Blue,
                    _ => null
                };

                if (brush == null)
                {
                    continue;
                }

                notes.Add(new Note(timeSec, brush));
            }

            return notes;
        }
    }
}
