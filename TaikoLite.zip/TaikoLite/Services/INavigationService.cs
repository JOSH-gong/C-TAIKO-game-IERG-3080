using System;

namespace TaikoLite.Services
{
    /// <summary>
    /// Provides abstraction for swapping the active view model.
    /// </summary>
    public interface INavigationService
    {
        object? CurrentViewModel { get; }

        event EventHandler? CurrentViewModelChanged;

        void Navigate(object viewModel);
    }
}
