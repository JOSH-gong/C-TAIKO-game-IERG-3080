using System.Windows.Input;
using TaikoLite.Services;
using TaikoLite.Utils;

namespace TaikoLite.ViewModels
{
    public class ResultViewModel
    {
        private readonly INavigationService _navigationService;

        public ResultViewModel(INavigationService navigationService, string songName, int score, int perfect, int good, int bad, int miss, int maxCombo)
        {
            _navigationService = navigationService;
            SongName = songName;
            Score = score;
            Perfect = perfect;
            Good = good;
            Bad = bad;
            Miss = miss;
            MaxCombo = maxCombo;

            BackCommand = new RelayCommand(_ =>
                _navigationService.Navigate(new SongSelectViewModel(_navigationService)));
        }

        public string SongName { get; }

        public int Score { get; }

        public int Perfect { get; }

        public int Good { get; }

        public int Bad { get; }

        public int Miss { get; }

        public int MaxCombo { get; }

        public ICommand BackCommand { get; }
    }
}
