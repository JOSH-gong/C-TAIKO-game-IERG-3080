using System.Windows.Input;
using TaikoLite.Services;
using TaikoLite.Utils;

namespace TaikoLite.ViewModels
{
    public class TitleViewModel
    {
        private readonly INavigationService _navigationService;

        public TitleViewModel(INavigationService navigationService)
        {
            _navigationService = navigationService;
            StartCommand = new RelayCommand(_ =>
                _navigationService.Navigate(new SongSelectViewModel(_navigationService)));
        }

        public ICommand StartCommand { get; }
    }
}
