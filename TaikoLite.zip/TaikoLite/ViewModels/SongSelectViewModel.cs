using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using TaikoLite.Models;
using TaikoLite.Services;
using TaikoLite.Utils;

namespace TaikoLite.ViewModels
{
    public class SongSelectViewModel : INotifyPropertyChanged
    {
        private readonly INavigationService _navigationService;
        private readonly RelayCommand _startGameCommand;
        private Song? _selectedSong;

        public SongSelectViewModel(INavigationService navigationService)
        {
            _navigationService = navigationService;
            Songs = new ObservableCollection<Song>
            {
                new Song("New Genesis", "Assets/Audio/New Genesis.mp3", offsetSec: 0.3, demoStartSec: 0.0, chartPath: "Assets/Charts/NewGenesis.chart"),
                new Song("Turing Love", "Assets/Audio/Turing Love.mp3", offsetSec: 0.3, demoStartSec: 0.0, chartPath: "Assets/Charts/TuringLove.chart"),
            };

            _selectedSong = Songs.FirstOrDefault();
            _startGameCommand = new RelayCommand(_ => StartGame(), _ => SelectedSong != null);
            StartGameCommand = _startGameCommand;
            BackCommand = new RelayCommand(_ => _navigationService.Navigate(new TitleViewModel(_navigationService)));
        }

        public ObservableCollection<Song> Songs { get; }

        public Song? SelectedSong
        {
            get => _selectedSong;
            set
            {
                if (_selectedSong == value)
                {
                    return;
                }

                _selectedSong = value;
                OnPropertyChanged(nameof(SelectedSong));
                _startGameCommand.RaiseCanExecuteChanged();
            }
        }

        public ICommand StartGameCommand { get; }

        public ICommand BackCommand { get; }

        private void StartGame()
        {
            var song = SelectedSong ?? Songs.First();
            _navigationService.Navigate(new GameViewModel(_navigationService, song));
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}