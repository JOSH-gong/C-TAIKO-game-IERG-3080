using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using TaikoLite.Models;
using TaikoLite.Services;
using TaikoLite.Utils;

namespace TaikoLite.ViewModels
{
    public class GameViewModel : INotifyPropertyChanged
    {
        private const double JudgeX = 250d;
        private const double SpeedPxPerSec = 300d;
        private const double TrackY = 200d;
        private const double PerfectWindow = 0.08d;
        private const double GoodWindow = 0.16d;
        private const double BadWindow = 0.25d;
        private const double TailSec = 1.5d;

        private readonly INavigationService _navigationService;
        private readonly DispatcherTimer _timer;
        private readonly DispatcherTimer _judgementTimer;
        private readonly DispatcherTimer _scorePopupTimer;
        private readonly Stopwatch _stopwatch = new();
        private readonly AudioService _audioService = new();
        private readonly double _songOffsetSec;
        private bool _hasFinished;
        private double _lastNoteTimeSec;

        private string? _judgementText;
        private double _judgementOpacity;
        private Brush _judgementBrush = Brushes.Transparent;
        private string? _scorePopupText;
        private double _scorePopupOpacity;
        private double _scorePopupYOffset;
        private Brush _scorePopupBrush = Brushes.Transparent;
        private int _score;
        private int _combo;
        private int _maxCombo;
        private int _perfectCount;
        private int _goodCount;
        private int _badCount;
        private int _missCount;
        private double _scorePopupElapsed;

        public GameViewModel(INavigationService navigationService, Song song)
        {
            _navigationService = navigationService;
            Song = song;
            SongName = song.Title;
            _songOffsetSec = song.OffsetSec;

            Notes = new ObservableCollection<Note>(ChartLoader.Load(Song.ChartPath));
            UpdateNotesPositions(GetCurrentSongTime());
            _lastNoteTimeSec = Notes.Any() ? Notes.Max(n => n.HitTimeSec) : 0d;

            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(16)
            };
            _timer.Tick += OnTick;

            _judgementTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(50)
            };
            _judgementTimer.Tick += OnJudgementTimerTick;

            _scorePopupTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(33)
            };
            _scorePopupTimer.Tick += OnScorePopupTick;

            QuitCommand = new RelayCommand(_ =>
            {
                StopLoop();
                _audioService.StopBgm();
                _navigationService.Navigate(new SongSelectViewModel(_navigationService));
            });

            FinishCommand = new RelayCommand(_ =>
            {
                StopLoop();
                _audioService.StopBgm();
                NavigateToResult();
            });

            StartPlayback();
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public Song Song { get; }

        public string SongName { get; }

        public ObservableCollection<Note> Notes { get; }

        public ICommand QuitCommand { get; }

        public ICommand FinishCommand { get; }

        public string? JudgementText
        {
            get => _judgementText;
            private set
            {
                if (_judgementText == value)
                {
                    return;
                }

                _judgementText = value;
                OnPropertyChanged(nameof(JudgementText));
            }
        }

        public double JudgementOpacity
        {
            get => _judgementOpacity;
            private set
            {
                if (Math.Abs(_judgementOpacity - value) < 0.0001)
                {
                    return;
                }

                _judgementOpacity = value;
                OnPropertyChanged(nameof(JudgementOpacity));
            }
        }

        public Brush JudgementBrush
        {
            get => _judgementBrush;
            private set
            {
                if (Equals(_judgementBrush, value))
                {
                    return;
                }

                _judgementBrush = value;
                OnPropertyChanged(nameof(JudgementBrush));
            }
        }

        public int Score
        {
            get => _score;
            private set
            {
                if (_score == value)
                {
                    return;
                }

                _score = value;
                OnPropertyChanged(nameof(Score));
            }
        }

        public int Combo
        {
            get => _combo;
            private set
            {
                if (_combo == value)
                {
                    return;
                }

                _combo = value;
                OnPropertyChanged(nameof(Combo));
            }
        }

        public int MaxCombo
        {
            get => _maxCombo;
            private set
            {
                if (_maxCombo == value)
                {
                    return;
                }

                _maxCombo = value;
                OnPropertyChanged(nameof(MaxCombo));
            }
        }

        public int PerfectCount
        {
            get => _perfectCount;
            private set
            {
                if (_perfectCount == value)
                {
                    return;
                }

                _perfectCount = value;
                OnPropertyChanged(nameof(PerfectCount));
            }
        }

        public int GoodCount
        {
            get => _goodCount;
            private set
            {
                if (_goodCount == value)
                {
                    return;
                }

                _goodCount = value;
                OnPropertyChanged(nameof(GoodCount));
            }
        }

        public int BadCount
        {
            get => _badCount;
            private set
            {
                if (_badCount == value)
                {
                    return;
                }

                _badCount = value;
                OnPropertyChanged(nameof(BadCount));
            }
        }

        public int MissCount
        {
            get => _missCount;
            private set
            {
                if (_missCount == value)
                {
                    return;
                }

                _missCount = value;
                OnPropertyChanged(nameof(MissCount));
            }
        }

        public string? ScorePopupText
        {
            get => _scorePopupText;
            private set
            {
                if (_scorePopupText == value)
                {
                    return;
                }

                _scorePopupText = value;
                OnPropertyChanged(nameof(ScorePopupText));
            }
        }

        public double ScorePopupOpacity
        {
            get => _scorePopupOpacity;
            private set
            {
                if (Math.Abs(_scorePopupOpacity - value) < 0.0001)
                {
                    return;
                }

                _scorePopupOpacity = value;
                OnPropertyChanged(nameof(ScorePopupOpacity));
            }
        }

        public double ScorePopupYOffset
        {
            get => _scorePopupYOffset;
            private set
            {
                if (Math.Abs(_scorePopupYOffset - value) < 0.0001)
                {
                    return;
                }

                _scorePopupYOffset = value;
                OnPropertyChanged(nameof(ScorePopupYOffset));
            }
        }

        public Brush ScorePopupBrush
        {
            get => _scorePopupBrush;
            private set
            {
                if (Equals(_scorePopupBrush, value))
                {
                    return;
                }

                _scorePopupBrush = value;
                OnPropertyChanged(nameof(ScorePopupBrush));
            }
        }

        public void OnKeyDown(Key key)
        {
            var wantsRed = key == Key.F || key == Key.D;
            var wantsBlue = key == Key.J || key == Key.K;

            if (!wantsRed && !wantsBlue)
            {
                return;
            }

            if (wantsRed)
            {
                _audioService.PlayHitRed();
            }
            else
            {
                _audioService.PlayHitBlue();
            }

            var targetBrush = wantsRed ? Brushes.Red : Brushes.Blue;
            var nowSec = GetCurrentSongTime();

            var candidate = Notes
                .Where(n => Equals(n.Brush, targetBrush))
                .OrderBy(n => Math.Abs(n.HitTimeSec - nowSec))
                .FirstOrDefault();

            if (candidate == null)
            {
                return;
            }

            var delta = Math.Abs(candidate.HitTimeSec - nowSec);
            if (delta > BadWindow)
            {
                return;
            }

            string judgement;

            int points;
            if (delta <= PerfectWindow)
            {
                PerfectCount++;
                points = 1000;
                Score += points;
                Combo++;
                judgement = "Perfect";
            }
            else if (delta <= GoodWindow)
            {
                GoodCount++;
                points = 600;
                Score += points;
                Combo++;
                judgement = "Good";
            }
            else
            {
                BadCount++;
                points = 200;
                Score += points;
                Combo = 0;
                judgement = "Bad";
            }

            MaxCombo = Math.Max(MaxCombo, Combo);

            Notes.Remove(candidate);
            ShowJudgement(judgement);
            ShowScorePopup(points, judgement);
        }

        private void ShowJudgement(string text)
        {
            JudgementText = text;
            JudgementBrush = text switch
            {
                "Perfect" => Brushes.Gold,
                "Good" => Brushes.DeepSkyBlue,
                "Bad" => Brushes.OrangeRed,
                "Miss" => Brushes.Gray,
                _ => Brushes.Gold
            };
            JudgementOpacity = 1.0;

            _judgementTimer.Stop();
            _judgementTimer.Start();
        }

        private void OnJudgementTimerTick(object? sender, EventArgs e)
        {
            const double fadeStep = 0.1d;

            if (JudgementOpacity <= 0)
            {
                _judgementTimer.Stop();
                JudgementText = string.Empty;
                JudgementBrush = Brushes.Transparent;
                return;
            }

            JudgementOpacity = Math.Max(0, JudgementOpacity - fadeStep);

            if (JudgementOpacity <= 0)
            {
                _judgementTimer.Stop();
                JudgementText = string.Empty;
                JudgementBrush = Brushes.Transparent;
            }
        }

        private void ShowScorePopup(int points, string judgement)
        {
            ScorePopupText = $"+{points}";
            ScorePopupBrush = judgement switch
            {
                "Perfect" => Brushes.Gold,
                "Good" => Brushes.DeepSkyBlue,
                "Bad" => Brushes.OrangeRed,
                _ => Brushes.Gold
            };
            ScorePopupOpacity = 1;
            ScorePopupYOffset = 0;
            _scorePopupElapsed = 0;

            _scorePopupTimer.Stop();
            _scorePopupTimer.Start();
        }

        private void OnScorePopupTick(object? sender, EventArgs e)
        {
            const double durationSec = 0.7d;
            const double riseDistance = -30d;

            _scorePopupElapsed += _scorePopupTimer.Interval.TotalSeconds;
            var progress = Math.Min(1d, _scorePopupElapsed / durationSec);

            ScorePopupOpacity = 1d - progress;
            ScorePopupYOffset = riseDistance * progress;

            if (progress >= 1d)
            {
                _scorePopupTimer.Stop();
                ScorePopupText = string.Empty;
                ScorePopupBrush = Brushes.Transparent;
                ScorePopupOpacity = 0;
                ScorePopupYOffset = riseDistance;
            }
        }

        private void StartPlayback()
        {
            _audioService.PlayBgm(Song.AudioPath, Song.DemoStartSec);
            _stopwatch.Restart();
            _timer.Start();
        }

        private void OnTick(object? sender, EventArgs e)
        {
            var nowSec = GetCurrentSongTime();
            UpdateNotesPositions(nowSec);

            if (!_hasFinished && !Notes.Any() && nowSec > _lastNoteTimeSec + TailSec)
            {
                _hasFinished = true;
                StopLoop();
                _audioService.StopBgm();
                NavigateToResult();
            }
        }

        private double GetCurrentSongTime() => _stopwatch.Elapsed.TotalSeconds - _songOffsetSec;

        private void UpdateNotesPositions(double nowSec)
        {
            foreach (var note in Notes.ToList())
            {
                if (nowSec - note.HitTimeSec > BadWindow)
                {
                    Notes.Remove(note);
                    RegisterMiss();
                    continue;
                }

                var newX = JudgeX + (note.HitTimeSec - nowSec) * SpeedPxPerSec;
                note.X = newX;
                note.Y = TrackY;

                if (newX < -50)
                {
                    Notes.Remove(note);
                }
            }
        }

        private void RegisterMiss()
        {
            MissCount++;
            Combo = 0;
            ShowJudgement("Miss");
        }

        private void NavigateToResult()
        {
            var result = new ResultViewModel(
                _navigationService,
                SongName,
                score: Score,
                perfect: PerfectCount,
                good: GoodCount,
                bad: BadCount,
                miss: MissCount,
                maxCombo: MaxCombo);

            _navigationService.Navigate(result);
        }

        private void StopLoop()
        {
            _timer.Stop();
            _timer.Tick -= OnTick;
            _stopwatch.Stop();
        }

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}