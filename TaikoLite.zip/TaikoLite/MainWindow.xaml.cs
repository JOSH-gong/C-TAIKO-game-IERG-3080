﻿using System.Windows;
using System.Windows.Input;
using TaikoLite.ViewModels;

namespace TaikoLite
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += (_, __) =>
            {
                Activate();
                Focus();
                Keyboard.Focus(this);
            };
        }
    }
}
