using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Media;

namespace TaikoLite.Models
{
    public class Note : INotifyPropertyChanged
    {
        private double _x;
        private double _y;

        public Note(double hitTimeSec, Brush brush)
        {
            HitTimeSec = hitTimeSec;
            Brush = brush;
        }

        public double HitTimeSec { get; }

        public Brush Brush { get; }

        public double X
        {
            get => _x;
            set
            {
                if (_x.Equals(value))
                {
                    return;
                }

                _x = value;
                OnPropertyChanged();
            }
        }

        public double Y
        {
            get => _y;
            set
            {
                if (_y.Equals(value))
                {
                    return;
                }

                _y = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}