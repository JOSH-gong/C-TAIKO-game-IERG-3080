namespace TaikoLite.Models
{
    public class Song
    {
        public Song(string title, string audioPath, double offsetSec = 2, double demoStartSec = 0, string? chartPath = null)
        {
            Title = title;
            AudioPath = audioPath;
            OffsetSec = offsetSec;
            DemoStartSec = demoStartSec;
            ChartPath = chartPath ?? string.Empty;
        }

        public string Title { get; }

        public string AudioPath { get; }

        public double OffsetSec { get; }

        public double DemoStartSec { get; }

        public string ChartPath { get; }
    }
}
