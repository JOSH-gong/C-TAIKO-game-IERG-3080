using System.Windows.Controls;

namespace TaikoLite.Views
{
    public partial class SongSelectView : UserControl
    {
        public SongSelectView()
        {
            InitializeComponent();
        }
    }
}
