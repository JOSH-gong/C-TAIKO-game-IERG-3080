﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using TaikoLite.ViewModels;

namespace TaikoLite.Views
{
    public partial class GameView : UserControl
    {
        public GameView()
        {
            InitializeComponent();
            Focusable = true;
        }

        private void GameView_OnLoaded(object sender, RoutedEventArgs e)
        {
            // 延迟抢焦点，避免被按钮抢走
            Dispatcher.BeginInvoke(new System.Action(() =>
            {
                Focus();
                Keyboard.Focus(this);
            }), DispatcherPriority.Input);
        }

        private void GameView_OnKeyDown(object sender, KeyEventArgs e)
        {
            if (DataContext is GameViewModel vm)
            {
                vm.OnKeyDown(e.Key);
                e.Handled = true;
            }
        }
    }
}
