using System.Windows.Controls;

namespace TaikoLite.Views
{
    public partial class ResultView : UserControl
    {
        public ResultView()
        {
            InitializeComponent();
        }
    }
}
