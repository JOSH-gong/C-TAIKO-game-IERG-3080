using System.Windows.Controls;

namespace TaikoLite.Views
{
    public partial class TitleView : UserControl
    {
        public TitleView()
        {
            InitializeComponent();
        }
    }
}
